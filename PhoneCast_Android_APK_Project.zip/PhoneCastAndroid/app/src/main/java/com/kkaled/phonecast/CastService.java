package com.kkaled.phonecast;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.IBinder;
import android.util.Base64;
import android.view.Surface;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.List;

public class CastService extends Service {
    private static final int PORT = 8765;
    private static final int WIDTH = 1280;
    private static final int HEIGHT = 720;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaCodec encoder;
    private WsServer wsServer;
    private volatile boolean streaming = false;
    private byte[] spsPpsBuffer = null;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotification();
        if (intent != null) {
            int code = intent.getIntExtra("code", -1);
            Intent data = intent.getParcelableExtra("data");
            if (data != null) {
                MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                projection = mpm.getMediaProjection(code, data);
            }
        }

        if (wsServer == null) {
            wsServer = new WsServer(new InetSocketAddress(PORT));
            wsServer.setReuseAddr(true);
            wsServer.start();
        }
        return START_STICKY;
    }

    private void createNotification() {
        String chId = "phonecast_ch";
        NotificationChannel ch = new NotificationChannel(chId, "PhoneCast", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        Notification n = new Notification.Builder(this, chId)
            .setContentTitle("PhoneCast متصل وجاهز")
            .setContentText("البث يعمل على المنفذ 8765")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build();
        startForeground(1, n);
    }

    private JSONArray getInstalledAppsJson() {
        JSONArray arr = new JSONArray();
        try {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            for (ResolveInfo ri : list) {
                JSONObject o = new JSONObject();
                String pkg = ri.activityInfo.packageName;
                String label = ri.loadLabel(pm).toString();
                o.put("pkg", pkg);
                o.put("label", label);
                try {
                    Drawable icon = ri.loadIcon(pm);
                    Bitmap bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(bmp);
                    icon.setBounds(0, 0, 64, 64);
                    icon.draw(c);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.PNG, 80, bos);
                    o.put("icon", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP));
                } catch (Exception ignored) {}
                arr.put(o);
            }
        } catch (Exception ignored) {}
        return arr;
    }

    private void startH264Stream(WebSocket conn, String pkg) {
        stopH264Stream();
        if (projection == null) return;
        try {
            MediaFormat fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, WIDTH, HEIGHT);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 3500000);
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            encoder.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            Surface surface = encoder.createInputSurface();
            encoder.start();

            virtualDisplay = projection.createVirtualDisplay(
                "PhoneCastDisplay", WIDTH, HEIGHT, 213,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR | DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
                surface, null, null
            );

            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    ActivityOptions opts = ActivityOptions.makeBasic();
                    opts.setLaunchDisplayId(virtualDisplay.getDisplay().getDisplayId());
                    startActivity(launchIntent, opts.toBundle());
                } catch (Exception e) {
                    startActivity(launchIntent);
                }
            }

            streaming = true;
            new Thread(() -> {
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (streaming) {
                    try {
                        int idx = encoder.dequeueOutputBuffer(info, 10000);
                        if (idx >= 0) {
                            ByteBuffer buf = encoder.getOutputBuffer(idx);
                            if (buf != null && info.size > 0) {
                                byte[] outData = new byte[info.size];
                                buf.get(outData);
                                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                    spsPpsBuffer = outData;
                                }
                                if (conn.isOpen()) {
                                    if ((info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0 && spsPpsBuffer != null) {
                                        byte[] combined = new byte[spsPpsBuffer.length + outData.length];
                                        System.arraycopy(spsPpsBuffer, 0, combined, 0, spsPpsBuffer.length);
                                        System.arraycopy(outData, 0, combined, spsPpsBuffer.length, outData.length);
                                        conn.send(combined);
                                    } else {
                                        conn.send(outData);
                                    }
                                }
                            }
                            encoder.releaseOutputBuffer(idx, false);
                        }
                    } catch (Exception e) {
                        break;
                    }
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopH264Stream() {
        streaming = false;
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        try { if (encoder != null) { encoder.stop(); encoder.release(); } } catch (Exception ignored) {}
        virtualDisplay = null;
        encoder = null;
    }

    private class WsServer extends WebSocketServer {
        public WsServer(InetSocketAddress addr) { super(addr); }

        @Override public void onOpen(WebSocket conn, ClientHandshake handshake) {}
        @Override public void onClose(WebSocket conn, int code, String reason, boolean remote) { stopH264Stream(); }
        @Override public void onError(WebSocket conn, Exception ex) {}
        @Override public void onStart() {}

        @Override
        public void onMessage(WebSocket conn, String message) {
            try {
                JSONObject msg = new JSONObject(message);
                String t = msg.optString("t");
                if ("list".equals(t)) {
                    JSONObject res = new JSONObject();
                    res.put("t", "apps");
                    res.put("list", getInstalledAppsJson());
                    conn.send(res.toString());
                } else if ("launch".equals(t)) {
                    String pkg = msg.optString("pkg");
                    startH264Stream(conn, pkg);
                } else if ("detach".equals(t)) {
                    stopH264Stream();
                } else if ("tap".equals(t)) {
                    float x = (float) msg.optDouble("x", 0.5) * WIDTH;
                    float y = (float) msg.optDouble("y", 0.5) * HEIGHT;
                    if (InputAccessibilityService.instance != null) {
                        InputAccessibilityService.instance.performTap(x, y);
                    }
                } else if ("key".equals(t)) {
                    String code = msg.optString("code");
                    if (InputAccessibilityService.instance != null) {
                        InputAccessibilityService.instance.performKey(code);
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
