package com.kkaled.phonecast;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PROJECTION = 1001;
    private MediaProjectionManager mpm;
    private TextView statusTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(64, 64, 64, 64);
        root.setBackgroundColor(0xFF101828);

        TextView title = new TextView(this);
        title.setText("PhoneCast 📺");
        title.setTextSize(32f);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView ipView = new TextView(this);
        ipView.setText("IP التليفون لكتابته على الشاشة:\n" + getWifiIp());
        ipView.setTextSize(24f);
        ipView.setTextColor(0xFF5AB4FF);
        ipView.setGravity(Gravity.CENTER);
        ipView.setPadding(0, 40, 0, 40);
        root.addView(ipView);

        statusTv = new TextView(this);
        statusTv.setText("المنفذ: 8765 (متوافق مع تطبيق الشاشة PhoneCast)");
        statusTv.setTextSize(16f);
        statusTv.setTextColor(0xFF7BE07B);
        statusTv.setGravity(Gravity.CENTER);
        statusTv.setPadding(0, 0, 0, 40);
        root.addView(statusTv);

        Button startBtn = new Button(this);
        startBtn.setText("1. تشغيل سيرفر البث للشاشة");
        startBtn.setTextSize(20f);
        startBtn.setOnClickListener(v -> {
            mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
        });
        root.addView(startBtn);

        Button accBtn = new Button(this);
        accBtn.setText("2. تفعيل التحكم بالريموت (Accessibility)");
        accBtn.setTextSize(18f);
        accBtn.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        root.addView(accBtn);

        setContentView(root);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_PROJECTION && resultCode == RESULT_OK && data != null) {
            Intent svc = new Intent(this, CastService.class);
            svc.putExtra("code", resultCode);
            svc.putExtra("data", data);
            startForegroundService(svc);
            statusTv.setText("✅ السيرفر شغال الآن! اكتب الـ IP على الشاشة واضغط اتصال");
        }
    }

    private String getWifiIp() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            WifiInfo info = wm.getConnectionInfo();
            int ip = info.getIpAddress();
            return String.format(Locale.US, "%d.%d.%d.%d",
                (ip & 0xff), (ip >> 8 & 0xff), (ip >> 16 & 0xff), (ip >> 24 & 0xff));
        } catch (Exception e) {
            return "192.168.1.x";
        }
    }
}
