package com.kkaled.phonecast;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class InputAccessibilityService extends AccessibilityService {
    public static InputAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    public void performTap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, 60));
        dispatchGesture(b.build(), null, null);
    }

    public void performKey(String code) {
        if ("BACK".equals(code)) performGlobalAction(GLOBAL_ACTION_BACK);
        else if ("HOME".equals(code)) performGlobalAction(GLOBAL_ACTION_HOME);
    }
}
